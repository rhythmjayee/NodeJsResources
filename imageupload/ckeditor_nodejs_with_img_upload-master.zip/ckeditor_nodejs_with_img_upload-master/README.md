# ckeditor_nodejs_with_img_upload
This is full and functional new CKEditor with NodeJs integration. Along with image upload and browser from server as well. Which is not availble with CKEditor free. So enjoy FREE image upload too.

## Also have AWS S3 upload and browse function included
So that you can integrate with S3 and browse and upload files/images from CkEditor.

## How to install

1. Keep the ckeditor folder into your public folder

2. In your app.js or any other router controller add the code I have written here in app.js

3. Create your view template file here it is index.hbs You can change the path in both app.js and template file as well.

4. Need to install following NPM module:
    
    https://www.npmjs.com/package/fs [run this command: npm install fs --save]
    
    https://www.npmjs.com/package/connect-busboy  [run this command: npm install connect-busboy --save]

5. When you run that template file's page. You should see the ckeditor. When you click on image icon you will get both browse from server [along with creating folder]. And upload new file as well.

### Any question or help kindly update me.
